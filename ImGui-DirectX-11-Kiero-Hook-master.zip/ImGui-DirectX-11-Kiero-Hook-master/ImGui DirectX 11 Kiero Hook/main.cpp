#include "includes.h"
#include <codecvt>

static auto gameModule = (DWORD)GetModuleHandle("GameAssembly.dll");
uintptr_t* localPlayerPtr = (uintptr_t*)(gameModule + 0xDA5A84);
static auto unityModule = (DWORD)GetModuleHandle("UnityPlayer.dll");
std::wstring_convert<std::codecvt_utf8<wchar_t>, wchar_t> converter;

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

Present oPresent;
HWND window = NULL;
WNDPROC oWndProc;
ID3D11Device* pDevice = NULL;
ID3D11DeviceContext* pContext = NULL;
ID3D11RenderTargetView* mainRenderTargetView;

HANDLE process_handle;


//CHEAT OPTIONS
bool show = true;
static int switchTabs = 7;
static bool txtp = true;
static bool NoClip = false;
static bool RealTele2Med = false;
static bool Tele2Med = false;
static bool Emergcyamt = false;
static bool turnImposter = false;
static bool GettoESP = false;
static bool turnCrewmate = false;
static bool killDistanceCheckbox = false;
static bool turnGhost = false;
static bool localPlayerSpeed = false;
static float playerSpeed = 1.f;
static float playerS;
static float crewS;
static float killS;
static int LobkillS;
static int killdist;
static int EmergcyCount;
static bool CrewLight = false;
static bool Killtime = false;
std::wstring name(10, ' ');
// ACTUAL CHEAT FUNCTIONS





void InitImGui()
{
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
    ImGui_ImplWin32_Init(window);
    ImGui_ImplDX11_Init(pDevice, pContext);


}

LRESULT __stdcall WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    if (true && ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam))
        return true;

    return CallWindowProc(oWndProc, hWnd, uMsg, wParam, lParam);

}




bool init = false;
HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
    if (!init)
    {
        if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&pDevice)))
        {
            pDevice->GetImmediateContext(&pContext);
            DXGI_SWAP_CHAIN_DESC sd;
            pSwapChain->GetDesc(&sd);
            window = sd.OutputWindow;
            ID3D11Texture2D* pBackBuffer;
            pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);
            pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
            pBackBuffer->Release();
            oWndProc = (WNDPROC)SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)WndProc);
            InitImGui();
            init = true;

        }

        else
            return oPresent(pSwapChain, SyncInterval, Flags);
    }


    if (GetAsyncKeyState(VK_END)) {
        kiero::shutdown();
        return 0;
    }

    if (GetAsyncKeyState(VK_INSERT) & 1)
    {
        show = !show;
    }

    // menu start :0

    uintptr_t* localPlayerPtr = (uintptr_t*)(gameModule + 0xDA5A84);
    if (show)
    {
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        ImGui::SetNextWindowSize({ 325, 0 });
        ImGui::Begin("Among Us");
        ImGui::SetWindowSize({ 325, 0 }, ImGuiCond_Always);
        ImGui::SetNextWindowSize({ 325, 0 });
        auto& style = ImGui::GetStyle();
        style.Colors[ImGuiCol_TitleBg] = ImVec4{ 164.f / 255.f, 130.f / 255.f, 21.f / 255.f, 1.f };
        style.Colors[ImGuiCol_TitleBgActive] = ImVec4{ 164.f / 255.f, 130.f / 255.f, 21.f / 255.f, 1.f };
        style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4{ 164.f / 255.f, 130.f / 255.f, 21.f / 255.f, 1.f };
        style.Colors[ImGuiCol_Button] = ImVec4{ 164.f / 255.f, 130.f / 255.f, 21.f / 255.f, 1.f };
        // tabs
        if (ImGui::Button("Main", ImVec2(100.0f, 0.0f)))
            switchTabs = 0;
        ImGui::SameLine(0.0, 2.0f);
        if (ImGui::Button("Visuals", ImVec2(100.0f, 0.0f)))
            switchTabs = 1;
        ImGui::SameLine(0.0, 2.0f);
        if (ImGui::Button("Teleportation", ImVec2(100.0f, 0.0f)))
            switchTabs = 2;
        //ImGui::ShowStyleEditor();
        //ImGui::ShowFontSelector("Font Selector");

        switch (switchTabs)
        {
        case 0: //Main TAB

            ImGui::Checkbox("Im Imposter", &turnImposter);
            ImGui::SameLine(0.0, 6.0f);
            ImGui::Checkbox("Im Crewmate", &turnCrewmate);
            ImGui::SameLine(0.0, 6.0f);
            ImGui::Checkbox("Im Ghost", &turnGhost);
            if (turnImposter)
            {
                uintptr_t imposAddr = memtools::FindDMAAddyInternal(gameModule + 0xDAF3E8, { 0x5C, 0x20, 0x34, 0x28 });
                int* imposval = (int*)imposAddr;
                *imposval = 1;
            }
            if (turnCrewmate)
            {
                uintptr_t crewmateAddr = memtools::FindDMAAddyInternal(gameModule + 0xDAF3E8, { 0x5C, 0x20, 0x34, 0x28 });
                int* cewsval = (int*)crewmateAddr;
                *cewsval = 0;
            }
            if (turnGhost)
            {
                uintptr_t ghost2Addr = memtools::FindDMAAddyInternal(gameModule + 0xDAF3E8, { 0x5C, 0x20, 0x34, 0x28 });
                int* ghost3val = (int*)ghost2Addr;
                *ghost3val = 257;
            }

            ImGui::Checkbox("No Clip", &NoClip);
            ImGui::SameLine(0.0, 6.0f);
            if (ImGui::Button("Teleport Out Of Start Ship"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 0.06919130683f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 5.171265125f;
            }
            if (NoClip)
            {
                //using unity module addy instead of gameassembly
                uintptr_t NoClipAddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x0 });
                int* lulnoclip = (int*)NoClipAddy;
                *lulnoclip = 1;
            }
            else
            {
                intptr_t NoClipAddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x0 });
                int* lulnoclip = (int*)NoClipAddy;
                *lulnoclip = 2;
            }


            ImGui::Checkbox("Speed", &localPlayerSpeed);
            ImGui::SameLine(0.0, 12.0f);
            ImGui::SliderFloat(" ", &playerS, 1.f, 20.f);
            if (localPlayerPtr)
            {
                if (localPlayerSpeed)
                {
                    uintptr_t speedAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x14 });
                    float* playerSpeed = (float*)speedAddr;
                    *playerSpeed = playerS; // <-- causing crashes
                }
                else
                {
                    intptr_t speedAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x14 });
                    float* playerSpeedlim = (float*)speedAddr;
                    *playerSpeedlim = 1.f; // <-- causing crashes
                }
            }
            ImGui::Checkbox("Crew Light", &CrewLight);
            ImGui::SameLine(0.0, 10.0f);
            ImGui::SliderFloat("", &crewS, 1.f, 20.f);
            if (localPlayerPtr)
            {
                if (CrewLight)
                {
                    uintptr_t lightAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x18 });
                    float* playerlight = (float*)lightAddr;
                    *playerlight = crewS;
                }
                else
                {
                    uintptr_t lightAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x18 });
                    float* playerlight = (float*)lightAddr;
                    *playerlight = 1.f;
                }
            }
            ImGui::Checkbox("Kill Cool Down", &Killtime);
            ImGui::SameLine(0.0, 10.0f);
            ImGui::SliderFloat("  ", &killS, 1.f, 15.f);

            if (localPlayerPtr)
            {
                if (Killtime)
                {
                    uintptr_t KilltimeAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x20 });
                    float* KillTimerL = (float*)KilltimeAddr;
                    *KillTimerL = killS;
                }
                else
                {
                    uintptr_t KilltimeAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x20 });
                    float* KillTimerL = (float*)KilltimeAddr;
                    *KillTimerL = 15.f;
                }
            }
            ImGui::Checkbox("Voting Time", &Tele2Med); //GameAssembly.dll + DA5A84
            ImGui::SameLine(0.0, 10.0f);
            ImGui::SliderInt("   ", &LobkillS, 1, 20);

            if (Tele2Med)
            {
                uintptr_t xdtimeAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x48 });
                int* KillasgeerL = (int*)xdtimeAddr;
                *KillasgeerL = LobkillS;
            }
            else
            {
                uintptr_t xdtimeAddr = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x48 });
                int* KillasgeerL = (int*)xdtimeAddr;
                *KillasgeerL = 120;
            }

            ImGui::Checkbox("Emergency Calls", &Emergcyamt); //GameAssembly.dll + DA5A84
            ImGui::SameLine(0.0, 10.0f);
            ImGui::SliderInt("    ", &EmergcyCount, 1, 30);

            if (Emergcyamt)
            {
                uintptr_t EmergAddy = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x0, 0x48 });
                int* EmergerL = (int*)EmergAddy;
                *EmergerL = EmergcyCount;
            }
            else
            {
                uintptr_t xEmergAddy = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x0, 0x48 });
                int* EmergerL = (int*)xEmergAddy;
                *EmergerL = 1;
            }

            ImGui::Checkbox("Kill Distance", &killDistanceCheckbox); //GameAssembly.dll + DA5A84
            ImGui::SameLine(0.0, 10.0f);
            ImGui::SliderInt("     ", &killdist, 1, 3);

            if (killDistanceCheckbox)
            {
                uintptr_t killdistaddy = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x40 });
                int* killd = (int*)killdistaddy;
                *killd = killdist;
            }
            else
            {
                uintptr_t killdistaddy = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x40 });
                int* killd = (int*)killdistaddy;
                *killd = 1;
            }


            break;
        case 1: // Visuals
          if(txtp)
          {
            uintptr_t killdistaddy = memtools::FindDMAAddyInternal(gameModule + 0xDA5A84, { 0x5C, 0x4, 0x40 });
            memcpy((void*)name.data(), (void*)killdistaddy, 20);
            std::string converted_str = converter.to_bytes(name);
            ImGui::Text(converted_str.c_str());
          }

            break;
        case 2: //Teleportation

            if (ImGui::Button("The Skeld", ImVec2(100.0f, 0.0f)))
                switchTabs = 3;
            ImGui::SameLine(0.0, 2.0f);
            if (ImGui::Button("Mirahq", ImVec2(100.0f, 0.0f)))
                switchTabs = 4;
            ImGui::SameLine(0.0, 2.0f);
            if (ImGui::Button("Polus", ImVec2(100.0f, 0.0f)))
                switchTabs = 5;

        case 3: //MAP THE SKELD
            ImGui::Text("Map -> THE SKELD");
            if (ImGui::Button("Med Bay"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -9.177800179f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -2.285377741f;
            }

            if (ImGui::Button("Report Table"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -0.8012289405f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 2.12445569f;
            }

            if (ImGui::Button("Camera Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -12.92269421f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -3.656251669f;
            }

            if (ImGui::Button("Reactor"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -20.58441544f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -5.441064358f;
            }

            if (ImGui::Button("Electric Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -6.85087347f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -8.838123322f;
            }


            if (ImGui::Button("Storage Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -4.249099255f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -13.35535336f;
            }

            if (ImGui::Button("Admin Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 5.10692215f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -8.005049706f;
            }

            if (ImGui::Button("Engine Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -17.0474205f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -9.72734642f;
            }

            if (ImGui::Button("SPACE"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -26.81193352f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -8.841944695f;
            }
            break;

        case 4: //MAP MIRAHQ
            ImGui::Text("Map -> MIRAHQ");
            if (ImGui::Button("Report Table"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 25.08257675f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 1.374570012f;
            }

            if (ImGui::Button("Storage Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 18.45582581f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 3.565962791f;
            }

            if (ImGui::Button("Satellite"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 19.9529686f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -2.586984873f;
            }


            if (ImGui::Button("Hallway Center"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 17.7395134f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 11.16385651f;
            }

            if (ImGui::Button("Admin Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 19.579216f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 18.58133507f;
            }

            if (ImGui::Button("Office"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 14.98454189f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 18.19694328f;
            }

            if (ImGui::Button("Communication"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 14.96714115f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 3.946860552f;
            }

            if (ImGui::Button("Locker Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 10.62946129f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 3.722297907f;
            }

            if (ImGui::Button("Med Bay"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 14.22113705f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -0.1889319718f;
            }

            if (ImGui::Button("Launch Pad"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = -4.008491993f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 0.1534152925f;
            }

            if (ImGui::Button("SPACE"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 26.20145226f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = 7.394963741f;
            }

            break;
        case 5: //MAP POLUS
            ImGui::Text("Map -> POLUS");

            if (ImGui::Button("Report Table"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 19.88724518f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -16.61142921f;
            }


            if (ImGui::Button("Admin Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 23.05901146f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -22.26737022f;
            }

            if (ImGui::Button("Office"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 27.0331955f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -17.17744637f;
            }

            if (ImGui::Button("MIDDLE OF LAVA!"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 34.07090378f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -16.13401794f;
            }


            if (ImGui::Button("Laboratory"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 26.65434837f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -9.835519791f;
            }

            if (ImGui::Button("Storage"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 20.31784248f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -11.88982487f;
            }

            if (ImGui::Button("Electrical"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 9.249729156f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -12.49947834f;
            }

            if (ImGui::Button("Oxygen / 02 Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 2.706996441f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -17.39266586f;
            }

            if (ImGui::Button("Boiler Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 2.526514292f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -23.75616837f;
            }

            if (ImGui::Button("Weapons Room"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 12.75616932f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -23.04491615f;
            }

            if (ImGui::Button("Communications"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 12.13513374f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -16.81485939f;
            }

            if (ImGui::Button("Out Of Map"))
            {
                //x
                uintptr_t xcordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x2C });
                float* xcordval = (float*)xcordaddy;
                *xcordval = 3.229459524f;
                //y
                uintptr_t ycordaddy = memtools::FindDMAAddyInternal(unityModule + 0x12A86E0, { 0x80, 0x5C, 0x30 });
                float* ycordval = (float*)ycordaddy;
                *ycordval = -32.23437881f;
            }

            break;
            break;

        }

        ImGui::End();

        ImGui::Render();

        pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    }
    return oPresent(pSwapChain, SyncInterval, Flags);
}

DWORD WINAPI MainThread(LPVOID lpReserved)
{
    bool init_hook = false;
    do
    {
        if (kiero::init(kiero::RenderType::D3D11) == kiero::Status::Success)
        {
            kiero::bind(8, (void**)&oPresent, hkPresent);
            init_hook = true;
        }
    } while (!init_hook);
    return TRUE;
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved)
{
    switch (dwReason)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hMod);
        CreateThread(nullptr, 0, MainThread, hMod, 0, nullptr);
        break;
    case DLL_PROCESS_DETACH:
        kiero::shutdown();
        break;
    }
    return TRUE;
}